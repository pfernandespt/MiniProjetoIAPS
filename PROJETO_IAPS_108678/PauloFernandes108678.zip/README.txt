Ficheiros relativos ao MiniProjeto de IAPS 2023
Título: Sistema de Comunicação Full-Duplex através de sinais sonoros
Por: Paulo Fernandes 108678
Email: paulofernandes@ua.pt

Este projeto encontra-se disponível no GitHub: https://github.com/pfernandespt/MiniProjetoIAPS

Nesta pasta encontram-se:
	- Proposta de Trabalho
	- Relatório Final
	- Código desenvolvido (ultima versão - v4)
	- Gráficos/imagens adicionais
	- Atalho para o vídeo de apresentação (https://youtu.be/KODtkI46DBQ)
	
NOTA IMPORTANTE: Depois de o programa ser executado pela última vez, para desligar o objeto de gravação de audio sem fechar o matlab, deve executar-se o seguinte comando na Command Window:
	>> delete(rec)

Caso tenha problemas em visualizar algum conteúdo, por favor, contacte-me. Obrigado