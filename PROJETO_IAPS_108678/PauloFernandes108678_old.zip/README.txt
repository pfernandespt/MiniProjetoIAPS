Ficheiros relativos ao MiniProjeto de IAPS 2023
Título: Sistema de Comunicação Full-Duplex através de sinais sonoros
Por: Paulo Fernandes 108678

Nesta pasta encontram-se:
	- Proposta de Trabalho
	- Relatório Final
	- Código desenvolvido
	- gráficos/imagens adicionais
	- Atalho para o vídeo de apresentação (https://youtu.be/KODtkI46DBQ)